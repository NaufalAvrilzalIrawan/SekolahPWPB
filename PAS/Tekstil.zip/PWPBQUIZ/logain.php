<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="soi.css">
    <title>Document</title>

</head>
<body>
    <div class="Login-box">
        <h2>Login </h2>
        <form action="proses/logda.php" method="post" name="login" id="login">
            <div class="user-box">
                <input type="text" name="user" id="user" required="">
                <label>Username</label>
            </div>
            <div class="user-box">
                <input type="text" name="pass" id="pass" required="">
                <label>Password</label>
            </div>
            <div class="button-form">
                <input type="submit" name="masuk" id="masuk" value="Login"></input>
            </div>
        </form>

        <script>
            
        </script>
</body>
</html>