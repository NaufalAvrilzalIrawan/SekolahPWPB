<?php
    $host="localhost";
    $username="root";
    $pass="";
    $database="tekstil";

    $koneksi=mysqli_connect($host, $username, $pass, $database) or die ("ndak nyambung");
?>
